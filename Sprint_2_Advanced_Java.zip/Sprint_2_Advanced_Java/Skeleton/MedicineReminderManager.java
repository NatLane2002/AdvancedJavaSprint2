import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;

/**
 * The MedicineReminderManager class should have methods to add reminders, get reminders
 *  1. for a specific user, and
 *  2. get reminders that are DUE for a specific user.
 *
 *  You'll need to integrate this class with your application and database logic to
 *  1. store,
 *  2. update, and
 *  3. delete reminders as needed.
 */

public class MedicineReminderManager {

    public MedicineReminderManager() {
    }

    // Method for adding a reminder
    public boolean addReminder(MedicineReminder reminder) {
        Connection con = DatabaseConnection.getCon();

        try {
            // Prepare the SQL query
            String query = "INSERT INTO medicine_reminders (id, user_id, medicine_name, dosage, schedule, start_date, end_date) VALUES (?, ?, ?, ?, ?, ?, ?)";

            // Database logic to insert data using PREPARED Statement
            PreparedStatement statement = con.prepareStatement(query);
            statement.setInt(1, reminder.getId());
            statement.setInt(2, reminder.getUserId());
            statement.setString(3, reminder.getMedicineName());
            statement.setString(4, reminder.getDosage());
            statement.setString(5, reminder.getSchedule());
            statement.setDate(6, java.sql.Date.valueOf(reminder.getStartDate()));
            statement.setDate(7, java.sql.Date.valueOf(reminder.getEndDate()));

            int updateRow = statement.executeUpdate();
            if (updateRow != 0) {
                System.out.println("Reminder added successfully");
                return true;
            }
        } catch (SQLException e) {
            System.out.println("Error adding reminder");
            e.printStackTrace();
            return false;
        }

        return false;
    }

    // Method for updating a reminder
    public void updateReminder(MedicineReminder updatedReminder) {
        Connection con = DatabaseConnection.getCon();

        try {
            // Prepare the SQL query
            String query = "UPDATE reminders SET user_id = ?, medicineName = ?, dosage = ?, schedule = ?, startDate = ?, endDate = ? WHERE id = ?";
    
            // Database logic to update data using PREPARED Statement
            PreparedStatement statement = con.prepareStatement(query);
            // Set the appropriate values for updating
            statement.setInt(1, updatedReminder.getUserId());
            statement.setString(2, updatedReminder.getMedicineName());
            statement.setString(3, updatedReminder.getDosage());
            statement.setString(4, updatedReminder.getSchedule());
            statement.setDate(5, java.sql.Date.valueOf(updatedReminder.getStartDate()));
            statement.setDate(6, java.sql.Date.valueOf(updatedReminder.getEndDate()));
            statement.setInt(7, updatedReminder.getId());
    
            int updateRow = statement.executeUpdate();
            if (updateRow != 0) {
                System.out.println("Reminder updated successfully");
            }
        } catch (SQLException e) {
            System.out.println("Error updating reminder");
            e.printStackTrace();
        }
    
    }

    // Method for deleting a reminder
    public void deleteReminder(int reminderId) {
        Connection con = DatabaseConnection.getCon();

        try {
            // Prepare the SQL query
            String query = "DELETE FROM medicine_reminders WHERE id = ?";

            // Database logic to delete data using PREPARED Statement
            PreparedStatement statement = con.prepareStatement(query);
            statement.setInt(1, reminderId);

            int updateRow = statement.executeUpdate();
            if (updateRow != 0) {
                System.out.println("Reminder deleted successfully");
            }
        } catch (SQLException e) {
            System.out.println("Error deleting reminder");
            e.printStackTrace();
        }
    }

    public List<MedicineReminder> getRemindersByUserId(int userId) {
        Connection con = DatabaseConnection.getCon();
        List<MedicineReminder> reminders = new ArrayList<>();

        try {
            // Prepare the SQL query
            String query = "SELECT * FROM medicine_reminders WHERE user_id = ?";

            // Database logic to get data using PREPARED Statement
            PreparedStatement statement = con.prepareStatement(query);
            statement.setInt(1, userId);

            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String medicineName = rs.getString("medicine_name");
                String dosage = rs.getString("dosage");
                String schedule = rs.getString("schedule");
                LocalDate startDate = rs.getDate("start_date").toLocalDate();
                LocalDate endDate = rs.getDate("end_date").toLocalDate();

                MedicineReminder temp = new MedicineReminder(id, userId, medicineName, dosage, schedule, startDate, endDate);
                reminders.add(temp);
            }
        } catch (SQLException e) {
            System.out.println("Error getting reminders");
            e.printStackTrace();
        }

        return reminders;
    }

    // Get reminders that are due for a specific user
    public List<MedicineReminder> getDueRemindersByUserId(int userId) {
        Connection con = DatabaseConnection.getCon();
        List<MedicineReminder> reminders = new ArrayList<>();

        try {
            // Prepare the SQL query
            String query = "SELECT * FROM medicine_reminders WHERE user_id = ? AND end_date >= ?";

            // Database logic to get data using PREPARED Statement
            PreparedStatement statement = con.prepareStatement(query);
            statement.setInt(1, userId);
            statement.setDate(2, java.sql.Date.valueOf(LocalDate.now()));

            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String medicineName = rs.getString("medicine_name");
                String dosage = rs.getString("dosage");
                String schedule = rs.getString("schedule");
                LocalDate startDate = rs.getDate("start_date").toLocalDate();
                LocalDate endDate = rs.getDate("end_date").toLocalDate();

                MedicineReminder reminder = new MedicineReminder(id, userId, medicineName, dosage, schedule, startDate, endDate);
                reminders.add(reminder);
            }
        } catch (SQLException e) {
            System.out.println("Error getting reminders");
            e.printStackTrace();
        }

        return reminders;
    }
}
