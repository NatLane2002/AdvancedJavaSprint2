public class GlobalVariables {
    public static User loggedInUser;
    public static Doctor loggedInDoctor;
}
