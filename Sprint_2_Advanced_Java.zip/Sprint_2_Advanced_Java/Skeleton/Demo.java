// import java.util.ArrayList;
// import java.util.Scanner;
// import java.sql.*;
// import org.mindrot.jbcrypt.*;
// import java.sql.SQLException;

// // ******************************************************************************************
// // THIS IS JUST A DEMO FOR NOW...BUT CAN BE EASILY MODIFIED TO WORK WITH THE REST OF THE CODE
// // ******************************************************************************************

// public class Demo {
//     public static void main(String[]args) {
//         DatabaseConnection databaseConnection = new DatabaseConnection();

//         boolean bool = false;
//         databaseConnection.getCon();

//         ArrayList<User> Temp = new ArrayList<>();
//         Scanner scanner = new Scanner(System.in);
//         int option = 0;

//         while(option != -1) {
//             System.out.println("Enter First Name: ");
//             String FN = scanner.nextLine();

//             System.out.println("Enter Last Name: ");
//             String LN = scanner.nextLine();

//             System.out.println("Enter registration number:");
//             String RegNo= scanner.nextLine();

//             System.out.println("Enter age: ");
//             int age = scanner.nextInt();
//             scanner.nextLine();

//             Temp.add(new User(age, RegNo, FN, LN, RegNo, false));

//             System.out.println("Enter -1 to exit or any other number to continue");
//             option = scanner.nextInt();
//             scanner.nextLine();
//         }
        
//         // Prepare the SQL query

//         String query = "INSERT INTO users (age, regno, firstname, lastname, password, isadmin) VALUES (?, ?, ?, ?, ?, ?)";

//         for(int i = 0; i < Temp.size(); i++) {
//             try {
//                 Connection con = DatabaseConnection.getCon();
//                 PreparedStatement statement = con.prepareStatement(query);
//                 statement.setString(1, Temp.get(i).getFirstName());
//                 statement.setString(2, Temp.get(i).getLastName());
//                 statement.setInt(3, Temp.get(i).getId());
//                 statement.setString(4, Temp.get(i).getEmail());
//                 int updateRow = statement.executeUpdate();
//                 if (updateRow != 0) {
//                     bool = true;
//                 }
//             } catch (SQLException e) {
//                 e.printStackTrace();
//             }
//         }

//         }

//     public static void ReadDB {
//         DatabaseConnection databaseConnection = new DatabaseConnection
//         ArrayList<Student> StudentList = new ArrayList<>()

//         String query = "SELECT * FROM student";
//         try {
//             Connection con = DatabaseConnection.getCon();
//             PreparedStatement statement = con.PreparedStatement(query);
//             ResultSet rs = statement.executeQuery();

//             while (rs.next()) {
//                 Student temp = new Student();
//                 temp.setFname(rs.getString("first_name"));
//                 temp.setLname(rs.getString("last_name"));
//                 temp.setAge(rs.getInt("age"));
//                 temp.setRegno(rs.getString("regno"));
//                 StudentList.add(temp);
//             }

//             con.close();

//         } catch (SQLException e) {
//             e.printStackTrace();
//         }

//         for(int i = 0; i < StudentList.size; i++) {
//             System.out.println(StudentList.get(i).toString());
//         }

//     }

    
// }