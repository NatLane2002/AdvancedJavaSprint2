// import com.DataBaseConnection;
import java.util.List;
import java.util.Scanner;
import java.time.LocalDate;

import org.mindrot.jbcrypt.BCrypt;

public class HealthMonitoringApp {

    private static UserDao userDao = new UserDao();
    private static DoctorPortalDao doctorPortalDao = new DoctorPortalDao();
    private static HealthDataDao healthDataDao = new HealthDataDao();
    private static RecommendationSystem recommendationSystem = new RecommendationSystem();
    private static MedicineReminderManager medicineReminderManager = new MedicineReminderManager();
    /**
     * Test the following functionalities within the Main Application
     *  1. Register a new user
     *  2. Log in the user
     *  3. Add health data
     *  4. Generate recommendations
     *  5. Add a medicine reminder
     *  6. Get reminders for a specific user
     *  7. Get due reminders for a specific user
     *  8. test doctor portal
     */

    public static void main(String[] args) {
        displayMenu();
    }
        
    public static void doctorPortal() {
        // Make sure a doctor is logged in
        if (GlobalVariables.loggedInDoctor == null) {
            System.out.println("\n");
            System.out.println("You must be logged in as a doctor to test the doctor portal. Please log in and try again");
            System.out.println("\n");
            displayMenu();
        }

        // Menu for the doctor portal
        System.out.println("\n");
        System.out.println("Welcome to the doctor portal!");
        System.out.println("Choose an option:");
        System.out.println("1. Fetch the doctor by ID");
        System.out.println("2. Fetch patients associated with the doctor");
        System.out.println("3. Fetch health data for the patient");
        System.out.println("4. Exit");
        System.out.println("\n");

        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                fetchDoctorById();
                break;
            case 2:
                fetchPatientsByDoctorId();
                break;
            case 3:
                fetchHealthDataByPatientId();
                break;
            case 4:
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
                break;
        }

    }

    // Fetch the doctor by ID (method 1)
    public static void fetchDoctorById() {
        // Make sure a doctor is logged in
        if (GlobalVariables.loggedInDoctor == null) {
            System.out.println("\n");
            System.out.println("You must be logged in as a doctor to fetch a doctor by ID. Please log in and try again");
            System.out.println("\n");
            displayMenu();
        }

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the doctor ID: ");
        int userId = scanner.nextInt();

        Doctor doctor = doctorPortalDao.getDoctorById(userId);

        if (doctor != null) {
            System.out.println("Doctor found");
            System.out.println(doctor);
        } else {
            System.out.println("Doctor not found");
        }
    }

    // Fetch patients associated with the doctor (method 2)
    public static void fetchPatientsByDoctorId() {
        // Make sure a doctor is logged in
        if (GlobalVariables.loggedInDoctor == null) {
            System.out.println("\n");
            System.out.println("You must be logged in as a doctor to fetch patients by doctor ID. Please log in and try again");
            System.out.println("\n");
            displayMenu();
        }

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the doctor ID: ");
        int doctorId = scanner.nextInt();

        List<User> patients = doctorPortalDao.getPatientsByDoctorId(doctorId);

        if (patients.size() == 0) {
            System.out.println('\n');
            System.out.println("No patients found for doctor " + doctorId);
            System.out.println('\n');
        } else if (patients.size() == 1) {
            System.out.println('\n');
            System.out.println("Here is the patient for doctor " + doctorId + ":");
            System.out.println(patients.get(0));
            System.out.println('\n');
        } else {
            System.out.println('\n');
            System.out.println("Here are the patients for doctor " + doctorId + ":");
            for (User patient : patients) {
                System.out.println(patient);
            }
            System.out.println('\n');
        }
    }

    // Fetch health data for the patient (method 3)
    public static void fetchHealthDataByPatientId() {
        // Make sure a doctor is logged in
        if (GlobalVariables.loggedInDoctor == null) {
            System.out.println("\n");
            System.out.println("You must be logged in as a doctor to fetch health data by patient ID. Please log in and try again");
            System.out.println("\n");
            displayMenu();
        }

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the patient ID: ");
        int patientId = scanner.nextInt();

        List<HealthData> healthData = doctorPortalDao.getHealthDataByPatientId(patientId);

        if (healthData.size() == 0) {
            System.out.println('\n');
            System.out.println("No health data found for patient " + patientId);
            System.out.println('\n');
        } else if (healthData.size() == 1) {
            System.out.println('\n');
            System.out.println("Here is the health data for patient " + patientId + ":");
            System.out.println(healthData.get(0));
            System.out.println('\n');
        } else {
            System.out.println('\n');
            System.out.println("Here are the health data for patient " + patientId + ":");
            for (HealthData data : healthData) {
                System.out.println(data);
            }
            System.out.println('\n');
        }
    }

    // Register a new user (method 1)
    public static void registerNewUser() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter your id: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Enter your first name: ");
        String firstName = scanner.nextLine();

        System.out.println("Enter your last name: ");
        String lastName = scanner.nextLine();

        System.out.println("Enter your email: ");
        String email = scanner.nextLine();

        System.out.println("Enter your password: ");
        String password = scanner.nextLine();

        System.out.println("Are you a doctor? (y/n): ");
        String isDoctor = scanner.nextLine().toLowerCase();

        while (!isDoctor.equals("y") && !isDoctor.equals("n")) {
            isDoctor = scanner.nextLine().toLowerCase();
            if (!isDoctor.equals("y") && !isDoctor.equals("n")) {
                System.out.println("Please enter 'y' or 'n'.");
            }
        }

        System.out.println("Enter your doctor's ID (Or enter anything else if you don't have a doctor): ");
        Integer doctorId = null;
        
        try {
            doctorId = scanner.nextInt();
        } catch (Exception e) {
            System.out.println("You don't have a doctor.");
        } finally {
            scanner.nextLine();
        }
        

        boolean isDoctorBool = isDoctor.equals("y");
        // Ask additional questions if the user is a doctor
        if (isDoctorBool) {

            System.out.println("Enter your medical license number: ");
            String medicalLicenseNumber = scanner.nextLine();

            System.out.println("Enter your specialization: ");
            String specialization = scanner.nextLine();

            Doctor user;

            user = new Doctor(id, firstName, lastName, email, password, true, doctorId, medicalLicenseNumber, specialization);

            if (userDao.createDoctor(user)) {
                System.out.println("Doctor user created successfully!");
            } else {
                System.out.println("Error creating user!");
            }
        } else {
            User user;

            user = new User(id, firstName, lastName, email, password, false, doctorId);

            if (userDao.createUser(user)) {
                System.out.println("Patient user created successfully!");
            } else {
                System.out.println("Error creating user!");
            }
        }

    }

    // Login a user (method 2)
    public static boolean loginUser() {

        // Check if the user is already logged in
        if (GlobalVariables.loggedInUser != null && GlobalVariables.loggedInUser != null) {
            System.out.println("\n");
            System.out.println("You are already logged in as a patient. Please log out and try again.");
            System.out.println("\n");
            displayMenu();
        }

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter your email: ");
        String email = scanner.nextLine();

        System.out.println("Enter your password: ");
        String password = scanner.nextLine();

        boolean loginSuccess = authenticateLogin("patient", email, password);

        if (loginSuccess) {
            System.out.println("Login successful!");
            // Set the logged in user in the GlobalVariables class
            GlobalVariables.loggedInUser = userDao.getUserByEmail(email);
            return true;
        } else {
            System.out.println("Login failed! Please check your credentials and try again.");
            return false;
        }

    }

    // Login a doctor (method 3)
    public static boolean loginDoctor() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter your email: ");
        String email = scanner.nextLine();

        System.out.println("Enter your password: ");
        String password = scanner.nextLine();

        boolean loginSuccess = authenticateLogin("doctor", email, password);

        if (loginSuccess) {
            System.out.println("Login successful!");
            // Set the logged in doctor in the GlobalVariables class
            GlobalVariables.loggedInDoctor = doctorPortalDao.getDoctorByEmail(email);
            return true;
        } else {
            System.out.println("Login failed! Please check your credentials and try again.");
            return false;
        }

    }

    public static boolean authenticateLogin(String userType, String email, String password) {
        if (userType.equals("doctor")) {
            //implement method to login doctor.
            Doctor doctor = doctorPortalDao.getDoctorByEmail(email);

            if (doctor != null) {
                // Compare the stored hashed password with the given password and return result
                System.out.println("Doctor found");
                return BCrypt.checkpw(password, doctor.getPassword());
            } else {
                System.out.println("Doctor not found");
            }

            return false;
        } else {
            //implement method to login user.
            User user = userDao.getUserByEmail(email);

            if (user != null) {
                // Compare the stored hashed password with the given password and return result
                System.out.println("User found");
                return BCrypt.checkpw(password, user.getPassword());
            } else {
                System.out.println("User not found");
            }

            return false;
        }

    }

    // Add health data (method 4)
    public static void addHealthData() {

        // If the user is not logged in, ask them to log in first
        if (GlobalVariables.loggedInUser == null) {
            System.out.println("\n");
            System.out.println("You must be logged in as a patient to add health data. Please log in and try again");
            System.out.println("\n");
            displayMenu();
        }

        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter the health data ID: ");
        int healthDataId = scanner.nextInt();

        System.out.println("Enter your weight (lbs): ");
        double weight = scanner.nextDouble();

        System.out.println("Enter your height (cm): ");
        double height = scanner.nextDouble();

        System.out.println("Enter your steps: ");
        int steps = scanner.nextInt();

        System.out.println("Enter your heart rate: ");
        int heartRate = scanner.nextInt();

        // Get today's date
        LocalDate date = LocalDate.now();

        HealthData healthData = new HealthData(healthDataId, GlobalVariables.loggedInUser.getId(), weight, height, steps, heartRate, date);

        if (healthDataDao.createHealthData(healthData)) {
            System.out.println("Health data created successfully!");
        } else {
            System.out.println("Error creating health data!");
        }
    }

    // Generate recommendations (method 5)
    public static void generateRecommendations() {
        // If the user is not logged in, ask them to log in first
        if (GlobalVariables.loggedInUser == null) {
            System.out.println("\n");
            System.out.println("You must be logged in as a patient to generate recommendations. Please log in and try again");
            System.out.println("\n");
            displayMenu();
        }

        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter the health data ID: ");
        int healthDataId = scanner.nextInt();

        System.out.println("Enter your weight (lbs): ");
        double weight = scanner.nextDouble();

        System.out.println("Enter your height (cm): ");
        double height = scanner.nextDouble();

        System.out.println("Enter your steps: ");
        int steps = scanner.nextInt();

        System.out.println("Enter your heart rate: ");
        int heartRate = scanner.nextInt();

        // Get today's date
        LocalDate date = LocalDate.now();

        HealthData healthData = new HealthData(healthDataId, GlobalVariables.loggedInUser.getId(), weight, height, steps, heartRate, date);

        // Generate recommendations
        List<String> recommendations = recommendationSystem.generateRecommendations(healthData);

        // Print recommendations
        System.out.println("\n");
        System.out.println("Here are your recommendations:");
        for (String recommendation : recommendations) {
            int numberOfRecommendations = 1;
            System.out.println(numberOfRecommendations + ". " + recommendation);
            numberOfRecommendations++;
        }
        System.out.println("\n");
    }

    // Add a medicine reminder (method 6)
    public static void addMedicineReminder() {
        // If the user is not logged in, ask them to log in first
        if (GlobalVariables.loggedInUser == null) {
            System.out.println("\n");
            System.out.println("You must be logged in as a patient to add a medicine reminder. Please log in and try again");
            System.out.println("\n");
            displayMenu();
        }

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the medicine reminder ID: ");
        int medicineReminderId = scanner.nextInt();

        scanner.nextLine();

        int userId = GlobalVariables.loggedInUser.getId();

        System.out.println("Enter the medicine name: ");
        String medicineName = scanner.nextLine();

        System.out.println("Enter the medicine dosage: ");
        String medicineDosage = scanner.nextLine();

        System.out.println("Enter the medicine frequency: ");
        String medicineFrequency = scanner.nextLine();

        System.out.println("Enter the medicine start date (yyyy-mm-dd): ");
        LocalDate medicineStartDate = LocalDate.parse(scanner.nextLine());

        System.out.println("Enter the medicine end date (yyyy-mm-dd): ");
        LocalDate medicineEndDate = LocalDate.parse(scanner.nextLine());

        MedicineReminder medicineReminder = new MedicineReminder(medicineReminderId, userId, medicineName, medicineDosage, medicineFrequency, medicineStartDate, medicineEndDate);

        if (medicineReminderManager.addReminder(medicineReminder)) {
            System.out.println("Medicine reminder created successfully!");
        } else {
            System.out.println("Error creating medicine reminder!");
        }
    }

    // Get reminders for a specific user (method 7)
    public static void getRemindersForUser() {
        // If the user is not logged in, ask them to log in first
        if (GlobalVariables.loggedInUser == null) {
            System.out.println("\n");
            System.out.println("You must be logged in as a patient to get reminders. Please log in and try again");
            System.out.println("\n");
            displayMenu();
        }

        Scanner scanner = new Scanner(System.in);

        int userId = GlobalVariables.loggedInUser.getId();

        List<MedicineReminder> reminders = medicineReminderManager.getRemindersByUserId(userId);

        if (reminders.size() == 0) {
            System.out.println('\n');
            System.out.println("No reminders found for user " + userId);
            System.out.println('\n');
        } else if (reminders.size() == 1) {
            System.out.println('\n');
            System.out.println("Here is the reminder for user " + userId + ":");
            System.out.println(reminders.get(0));
            System.out.println('\n');
        } else {
            System.out.println('\n');
            System.out.println("Here are the reminders for user " + userId + ":");
            for (MedicineReminder reminder : reminders) {
                System.out.println(reminder);
            }
            System.out.println('\n');
        }
    }
    
    // Get due reminders for a specific user (method 8)
    public static void getDueRemindersForUser() {
        // If the user is not logged in, ask them to log in first
        if (GlobalVariables.loggedInUser == null) {
            System.out.println("\n");
            System.out.println("You must be logged in as a patient to get reminders. Please log in and try again");
            System.out.println("\n");
            displayMenu();
        }

        int userId = GlobalVariables.loggedInUser.getId();

        List<MedicineReminder> dueReminders = medicineReminderManager.getDueRemindersByUserId(userId);

        if (dueReminders.size() == 0) {
            System.out.println('\n');
            System.out.println("No due reminders found for user " + userId);
            System.out.println('\n');
        } else if (dueReminders.size() == 1) {
            System.out.println('\n');
            System.out.println("Here is the due reminder for user " + userId + ":");
            System.out.println(dueReminders.get(0));
            System.out.println('\n');
        } else {
            System.out.println('\n');
            System.out.println("Here are the due reminders for user " + userId + ":");
            for (MedicineReminder dueReminder : dueReminders) {
                System.out.println(dueReminder);
            }
            System.out.println('\n');
        }
    }

    // Logout a user (method 10)
    public static void logout() {
        GlobalVariables.loggedInUser = null;
        GlobalVariables.loggedInDoctor = null;
        System.out.println("\n");
        System.out.println("You have been logged out successfully!");
        System.out.println("\n");
    }

// Display menu
private static void displayMenu() {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("Choose an option:");
            System.out.println("1. Register a new user");
            System.out.println("2. Patient log in");
            System.out.println("3. Doctor log in");
            System.out.println("4. Add health data");
            System.out.println("5. Generate recommendations");
            System.out.println("6. Add a medicine reminder");
            System.out.println("7. Get reminders for a specific user");
            System.out.println("8. Get due reminders for a specific user");
            System.out.println("9. Test doctor portal");
            System.out.println("10. Logout");
            System.out.println("0. Exit");

            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    registerNewUser();
                    break;
                case 2:
                    loginUser();
                    break;
                case 3:
                    loginDoctor();
                    break;
                case 4:
                    addHealthData();
                    break;
                case 5:
                    generateRecommendations();
                    break;
                case 6:
                    addMedicineReminder();
                    break;
                case 7:
                    getRemindersForUser();
                    break;
                case 8:
                    getDueRemindersForUser();
                    break;
                case 9:
                    doctorPortal();
                    break;
                case 10:
                    logout();
                    break;
                case 0:
                    System.out.println("Exiting the program. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }

        } while (choice != 0);
    }

}