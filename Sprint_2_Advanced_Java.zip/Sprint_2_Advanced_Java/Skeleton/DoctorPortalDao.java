import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DoctorPortalDao {

   // Complete all these methods and add more as needed

    public DoctorPortalDao() {
    };

    public Doctor getDoctorById(int doctorId) {
        int user_id = 0;
        String firstName = null;
        String lastName = null;
        String email = null;
        String password = null;
        boolean is_doctor = false;
        int doctor_id = 0;
        String medicalLicenseNumber = null;
        String specialization = null;

        // Prepare the SQL query
        String query = "SELECT * FROM doctors WHERE id = ?";

        // Database logic to get data by ID Using Prepared Statement
        try {
            Connection con = DatabaseConnection.getCon();
            PreparedStatement statement = con.prepareStatement(query);
            statement.setInt(1, doctorId);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                user_id = rs.getInt("id");
                firstName = rs.getString("first_name");
                lastName = rs.getString("last_name");
                email = rs.getString("email");
                password = rs.getString("password");
                is_doctor = rs.getBoolean("is_doctor");
                doctor_id = rs.getInt("doctor_id");
                medicalLicenseNumber = rs.getString("medical_license_number");
                specialization = rs.getString("specialization");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return new Doctor(user_id, firstName, lastName, email, password, is_doctor, doctor_id, medicalLicenseNumber, specialization);
    }

    public Doctor getDoctorByEmail(String email) { // get user by email from database
        int id = 0;
        String firstName = null;
        String lastName = null;
        String user_email = null;
        String password = null;
        boolean is_doctor = false;
        int doctor_id = 0;
        String medicalLicenseNumber = null;
        String specialization = null;

        // Prepare the SQL query
        String query = "SELECT * FROM doctors WHERE email = ?";
    try {
        Connection con = DatabaseConnection.getCon();
        PreparedStatement statement = con.prepareStatement(query);
        statement.setString(1, email);
        ResultSet rs = statement.executeQuery();
        while (rs.next()) {
            id = rs.getInt("id");
            firstName = rs.getString("first_name");
            lastName = rs.getString("last_name");
            user_email = rs.getString("email");
            password = rs.getString("password");
            is_doctor = rs.getBoolean("is_doctor");
            doctor_id = rs.getInt("doctor_id");
            medicalLicenseNumber = rs.getString("medical_license_number");
            specialization = rs.getString("specialization");
        }
    } catch (SQLException e){
        e.printStackTrace();
    }
    return new Doctor(id, firstName, lastName, user_email, password, is_doctor, doctor_id, medicalLicenseNumber, specialization);

    }

    public List<User> getPatientsByDoctorId(int doctorId) {
        // Get all the patients that have a column doctor_id with a value that matches the doctorId parameter
        ArrayList<User> UserList = new ArrayList<>();

        // Prepare the SQL query which will get all the patients from the database which have a doctor_id that matches the doctorId parameter
        String query = "SELECT * FROM users WHERE doctor_id = ?";

        // Database logic to get data by ID Using Prepared Statement
        try {
            Connection con = DatabaseConnection.getCon();
            PreparedStatement statement = con.prepareStatement(query);
            statement.setInt(1, doctorId);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                User temp = new User();
                temp.setId(rs.getInt("id"));
                temp.setFirstName(rs.getString("first_name"));
                temp.setLastName(rs.getString("last_name"));
                temp.setEmail(rs.getString("email"));
                temp.setPassword(rs.getString("password"));
                temp.setDoctor(rs.getBoolean("is_doctor"));
                temp.setDoctorId(rs.getInt("doctor_id"));
                UserList.add(temp);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    
        // Return the list of patients returned from the database
        return UserList;

    }

    public List<HealthData> getHealthDataByPatientId(int patientId) {
        // Get all the health data that have a column user_id with a value that matches the patientId parameter
        ArrayList<HealthData> healthDataList = new ArrayList<>();

        // Prepare the SQL query which will get all the health data from the database which have a user_id that matches the patientId parameter
        String query = "SELECT * FROM health_data WHERE user_id = ?";

        // Database logic to get data by ID Using Prepared Statement
        try {
            Connection con = DatabaseConnection.getCon();
            PreparedStatement statement = con.prepareStatement(query);
            statement.setInt(1, patientId);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                HealthData temp = new HealthData();
                temp.setId(rs.getInt("id"));
                temp.setUserId(rs.getInt("user_id"));
                temp.setWeight(rs.getDouble("weight"));
                temp.setHeight(rs.getDouble("height"));
                temp.setSteps(rs.getInt("steps"));
                temp.setHeartRate(rs.getInt("heart_rate"));
                temp.setDate(rs.getDate("date").toLocalDate());
                healthDataList.add(temp);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    
        // Return the list of health data returned from the database
        return healthDataList;
    }

    // Add more methods for other doctor-specific tasks

    public List<User> getPatientsAndDoctorsWithoutDoctor() {
        ArrayList<User> withoutDoctorList = new ArrayList<>();
    
        // Prepare the SQL queries to get patients and doctors without a doctor
        String patientQuery = "SELECT * FROM users WHERE doctor_id IS NULL";
        String doctorQuery = "SELECT * FROM doctors WHERE doctor_id IS NULL";
    
        try {
            Connection con = DatabaseConnection.getCon();
    
            // Get patients without a doctor
            PreparedStatement patientStatement = con.prepareStatement(patientQuery);
            ResultSet patientRs = patientStatement.executeQuery();
            while (patientRs.next()) {
                User patient = new User();
                patient.setId(patientRs.getInt("id"));
                patient.setFirstName(patientRs.getString("first_name"));
                patient.setLastName(patientRs.getString("last_name"));
                patient.setEmail(patientRs.getString("email"));
                patient.setPassword(patientRs.getString("password"));
                patient.setDoctor(patientRs.getBoolean("is_doctor"));
                patient.setDoctorId(patientRs.getInt("doctor_id"));
                withoutDoctorList.add(patient);
            }
    
            // Get doctors without a doctor
            PreparedStatement doctorStatement = con.prepareStatement(doctorQuery);
            ResultSet doctorRs = doctorStatement.executeQuery();
            while (doctorRs.next()) {
                Doctor doctor = new Doctor(
                    doctorRs.getInt("id"),
                    doctorRs.getString("first_name"),
                    doctorRs.getString("last_name"),
                    doctorRs.getString("email"),
                    doctorRs.getString("password"),
                    doctorRs.getBoolean("is_doctor"),
                    doctorRs.getInt("doctor_id"),
                    doctorRs.getString("medical_license_number"),
                    doctorRs.getString("specialization")
                );
                withoutDoctorList.add(doctor);
            }
    
        } catch (SQLException e) {
            e.printStackTrace();
        }
    
        // Return the list of users (patients and doctors) without a doctor
        return withoutDoctorList;
    }
    

    public boolean assignDoctorToPatient(int patientId, int doctorId) {
        // Prepare the SQL query which will update the 'doctor_id' column in the 'users' table for the given patient
        String query = "UPDATE users SET doctor_id = ? WHERE id = ?";

        // Database logic to update the 'doctor_id' column in the 'users' table for the given patient
        try {
            Connection con = DatabaseConnection.getCon();
            PreparedStatement statement = con.prepareStatement(query);
            statement.setInt(1, doctorId);
            statement.setInt(2, patientId);
            statement.executeUpdate();

            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean removeDoctorFromPatient(int patientId) {
        // Prepare the SQL query which will update the 'doctor_id' column in the 'users' table for the given patient
        String query = "UPDATE users SET doctor_id = NULL WHERE id = ?";

        // Database logic to update the 'doctor_id' column in the 'users' table for the given patient
        try {
            Connection con = DatabaseConnection.getCon();
            PreparedStatement statement = con.prepareStatement(query);
            statement.setInt(1, patientId);
            statement.executeUpdate();

            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
}

