import java.time.LocalDate;

public class HealthData {
    private int id;
    private int userId;
    private double weight;
    private double height;
    private int steps;
    private int heartRate;
    private LocalDate date;

    // Constructor, getters, and setters

    public HealthData() {
    }

    public HealthData(int id, int userId, double weight, double height, int steps, int heartRate, LocalDate date) {
        this.id = id;
        this.userId = userId;
        this.weight = weight;
        this.height = height;
        this.steps = steps;
        this.heartRate = heartRate;
        this.date = date;
    }

    // Get id
    public int getId() {
        return id;
    }

    // Set id
    public void setId(int id) {
        this.id = id;
    }

    // Get user id
    public int getUserId() {
        return userId;
    }

    // Set user id
    public void setUserId(int userId) {
        this.userId = userId;
    }

    // Get weight
    public double getWeight() {
        return weight;
    }

    // Set weight
    public void setWeight(double weight) {
        this.weight = weight;
    }

    // Get height
    public double getHeight() {
        return height;
    }

    // Set height
    public void setHeight(double height) {
        this.height = height;
    }

    // Get steps
    public int getSteps() {
        return steps;
    }

    // Set steps
    public void setSteps(int steps) {
        this.steps = steps;
    }

    // Get heart rate
    public int getHeartRate() {
        return heartRate;
    }

    // Set heart rate
    public void setHeartRate(int heartRate) {
        this.heartRate = heartRate;
    }

    // Get date
    public LocalDate getDate() {
        return date;
    }

    // Set date
    public void setDate(LocalDate date) {
        this.date = date;
    }

    // toString method
    @Override
    public String toString() {
        return "HealthData [date=" + date + ", heartRate=" + heartRate + ", height=" + height + ", id=" + id
                + ", steps=" + steps + ", userId=" + userId + ", weight=" + weight + "]";
    }

}