public class Doctor extends User {
    private String medicalLicenseNumber;
    private String specialization;

    public Doctor(int id, String firstName, String lastName, String email, String password, boolean isDoctor, Integer doctorId, String medicalLicenseNumber, String specialization) {
        super(id, firstName, lastName, email, password, isDoctor, doctorId);
        this.medicalLicenseNumber = medicalLicenseNumber;
        this.specialization = specialization;
    }

    // Getters and setters for the new properties

    // Get medical license number
    public String getMedicalLicenseNumber() {
        return medicalLicenseNumber;
    }

    // Set medical license number
    public void setMedicalLicenseNumber(String medicalLicenseNumber) {
        this.medicalLicenseNumber = medicalLicenseNumber;
    }

    // Get specialization
    public String getSpecialization() {
        return specialization;
    }

    // Set specialization
    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    // toString method
    public String toString() {
        return "Doctor{" +
                "medicalLicenseNumber='" + medicalLicenseNumber + '\'' +
                ", specialization='" + specialization + '\'' +
                '}';
    }
}
