import java.time.LocalDate;

public class MedicineReminder {
    private int id;
    private int userId;
    private String medicineName;
    private String dosage;
    private String schedule;
    private LocalDate startDate;
    private LocalDate endDate;

    // Constructor
    public MedicineReminder(int id, int userId, String medicineName, String dosage, String schedule, LocalDate startDate, LocalDate endDate) {
        this.id = id;
        this.userId = userId;
        this.medicineName = medicineName;
        this.dosage = dosage;
        this.schedule = schedule;
        this.startDate = startDate;
        this.endDate = endDate;
    }
    
    // Getters and setters

    // Get Id
    public int getId() {
        return id;
    }

    // Set Id
    public void setId(int id) {
        this.id = id;
    }

    // Get user ID
    public int getUserId() {
        return userId;
    }

    // Set user ID
    public void setUserId(int userId) {
        this.userId = userId;
    }

    // Get medicine name
    public String getMedicineName() {
        return medicineName;
    }

    // Set medicine name
    public void setMedicineName(String medicineName) {
        this.medicineName = medicineName;
    }

    // Get dosage
    public String getDosage() {
        return dosage;
    }

    // Set dosage
    public void setDosage(String dosage) {
        this.dosage = dosage;
    }

    // Get schedule
    public String getSchedule() {
        return schedule;
    }

    // Set schedule
    public void setSchedule(String schedule) {
        this.schedule = schedule;
    }

    // Get start date
    public LocalDate getStartDate() {
        return startDate;
    }

    // Set start date
    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    // Get end date
    public LocalDate getEndDate() {
        return endDate;
    }

    // Set end date
    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    // toString
    @Override
    public String toString() {
        return "MedicineReminder [id=" + id + ", userId=" + userId + ", medicineName=" + medicineName + ", dosage="
                + dosage + ", schedule=" + schedule + ", startDate=" + startDate + ", endDate=" + endDate + "]";
    }
    
}
