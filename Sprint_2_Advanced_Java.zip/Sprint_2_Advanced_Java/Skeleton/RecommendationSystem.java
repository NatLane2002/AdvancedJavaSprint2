import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * In this basic version of the
 * RecommendationSystem class, complete the generateRecommendations to take a
 * HealthData object as input and generates recommendations based on the user's heart rate and step count.
 * You can also expand this class to include more health data analysis and generate more specific
 * recommendations based on the user's unique health profile
 * NOTE:
 * To integrate this class into your application, you'll need to pass the HealthData object to the generateRecommendations method
 * and store the generated recommendations in the recommendations table in the database.
 */

// YOU NEED TO ADD THE RECOMMENDATION TO THE DATABASE IN THIS CLASS BECAUSE THIS IS WHERE THE RECOMMENDATIONS ARE GENERATED
// AND WHERE YOU CAN CALL healthData.getUserId() ETC AND ADD THOSE ATTRIBUTES TO THE RECOMMENDATIONS TABLE AS WELL

// AFTER THE recommendations ARRAY IS RETURNED, YOU NEED TO PUT IT ALL TOGETHER AS ONE
// STRING AND THEN ALONG WITH THE id, user_id, AND date, INSERT IT INTO THE recommendations TABLE IN THE POSTGRESQL DATABASE

public class RecommendationSystem {
        private static final int MIN_HEART_RATE = 60;
        private static final int MAX_HEART_RATE = 100;
        private static final int MIN_STEPS = 10000;

public List<String> generateRecommendations(HealthData healthData) {
        List<String> recommendations = new ArrayList<>();

        // Analyze heart rate
        int heartRate = healthData.getHeartRate();
        if (heartRate < MIN_HEART_RATE) {
                recommendations.add("Your heart rate is lower than the recommended range. " +
                        "Consider increasing your physical activity to improve your cardiovascular health.");
        } else if (heartRate > MAX_HEART_RATE) {
                recommendations.add("Your heart rate is higher than the recommended range. " +
                "Consider reducing your physical activity to improve your cardiovascular health.");
        } else {
                recommendations.add("Your heart rate is within the recommended range. Keep up the good work!");
        }

        // Analyze steps
        int steps = healthData.getSteps();
        if (steps < MIN_STEPS) {
                recommendations.add("You're not reaching the recommended daily step count. " +
                        "Try to incorporate more walking or other physical activities into your daily routine.");
        } else {
                recommendations.add("You're reaching the recommended daily step count. Keep up the good work!");
        }

        // Analyze weight
        double weight = healthData.getWeight() / 2.2;
        double height = healthData.getHeight() / 100;
        double bmi = weight / (height * height);
        if (bmi < 18.5) {
                recommendations.add("Your BMI is lower than the recommended range. " +
                        "Consider increasing your caloric intake to reach a healthy weight.");
        } else if (bmi > 25) {
                recommendations.add("Your BMI is higher than the recommended range. " +
                        "Consider reducing your caloric intake to reach a healthy weight.");
        } else {
                recommendations.add("Your BMI is within the recommended range. Keep up the good work!");
        }

        // Add user ID and date to the recommendations
        int userId = healthData.getUserId();
        LocalDate date = healthData.getDate();

        // Store recommendations in the database
        storeRecommendationsInDatabase(userId, date, recommendations);

        return recommendations;
}

private void storeRecommendationsInDatabase(int userId, LocalDate date, List<String> recommendations) {
        // database connection details
        Connection connection = DatabaseConnection.getCon();

        // SQL query to insert recommendations into the database
        String insertQuery = "INSERT INTO recommendations (user_id, recommendation_text, date ) VALUES (?, ?, ?)";

        try {
                // Prepare the SQL statement
                try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
                // Insert each recommendation into the database
                for (String recommendation : recommendations) {
                        preparedStatement.setInt(1, userId);
                        preparedStatement.setString(2, recommendation);
                        preparedStatement.setDate(3, java.sql.Date.valueOf(date));
                        preparedStatement.executeUpdate();
                }
        }
        } catch (SQLException e) {
                e.printStackTrace();
        } finally {
                // Close the connection
                try {
                if (connection != null) {
                        connection.close();
                }
                } catch (SQLException e) {
                e.printStackTrace();
        }
        }
}
}