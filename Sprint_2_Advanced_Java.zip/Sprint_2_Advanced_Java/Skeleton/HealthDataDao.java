import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;

public class HealthDataDao {

public boolean createHealthData(HealthData healthData) {
        Connection con = DatabaseConnection.getCon();

    try {
        // Prepare the SQL query
        String query = "INSERT INTO health_data (user_id, weight, height, steps, heart_rate, date) VALUES (?, ?, ?, ?, ?, ?)";

        // Database logic to insert data using PREPARED Statement
        PreparedStatement statement = con.prepareStatement(query);
        statement.setInt(1, healthData.getUserId());
        statement.setDouble(2, healthData.getWeight());
        statement.setDouble(3, healthData.getHeight());
        statement.setInt(4, healthData.getSteps());
        statement.setInt(5, healthData.getHeartRate());
        statement.setDate(6, java.sql.Date.valueOf(healthData.getDate()));

        int updateRow = statement.executeUpdate();
        if (updateRow != 0) {
            return true;
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return false;
    
}

public HealthData getHealthDataById(int id) {
        int health_data_id = 0;
        int user_id = 0;
        double weight = 0;
        double height = 0;
        int steps = 0;
        int heartRate = 0;
        LocalDate date = null;

        // Prepare the SQL query
        String query = "SELECT * FROM users WHERE id = ?";

        // Database logic to get data by ID Using Prepared Statement
        try {
            Connection con = DatabaseConnection.getCon();
            PreparedStatement statement = con.prepareStatement(query);
            statement.setInt(1, id);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                health_data_id = rs.getInt("id");
                user_id = rs.getInt("user_id");
                weight = rs.getInt("weight");
                height = rs.getInt("height");
                steps = rs.getInt("steps");
                heartRate = rs.getInt("heart_rate");
                date = rs.getDate("date").toLocalDate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return new HealthData(health_data_id, user_id, weight, height, steps, heartRate, date);
}

    public List<HealthData> getHealthDataByUserId(int userId) {
    List<HealthData> healthDataList = new ArrayList<>();
    
      // Prepare the SQL query
      String query = "SELECT * FROM health_data WHERE user_id = ?";

      // Database logic to get data by ID Using Prepared Statement
    try {
        Connection con = DatabaseConnection.getCon();
        PreparedStatement statement = con.prepareStatement(query);

        statement.setInt(1, userId);
        ResultSet rs = statement.executeQuery();

        while (rs.next()) {
            int health_data_id = rs.getInt("id");
            int user_id = rs.getInt("user_id");
            double weight = rs.getInt("weight");
            double height = rs.getInt("height");
            int steps = rs.getInt("steps");
            int heartRate = rs.getInt("heart_rate");
            LocalDate date = rs.getDate("date").toLocalDate();

            HealthData healthData = new HealthData(health_data_id, user_id, weight, height, steps, heartRate, date);
            healthDataList.add(healthData);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return healthDataList;

    }

    public boolean updateHealthData(HealthData healthData) {
    Connection con = DatabaseConnection.getCon();

    try {
        // Prepare the SQL query
        String query = "UPDATE health_data SET weight = ?, height = ?, steps = ?, heart_rate = ?, date = ? WHERE id = ?";

        // Database logic to insert data using PREPARED Statement
        PreparedStatement statement = con.prepareStatement(query);
        statement.setDouble(1, healthData.getWeight());
        statement.setDouble(2, healthData.getHeight());
        statement.setInt(3, healthData.getSteps());
        statement.setInt(4, healthData.getHeartRate());
        statement.setDate(5, java.sql.Date.valueOf(healthData.getDate()));
        statement.setInt(6, healthData.getId());

        int updateRow = statement.executeUpdate();
        if (updateRow != 0) {
            return true;
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return false;

}

    public boolean deleteHealthData(int id) {
        Connection con = DatabaseConnection.getCon();

        try {
        // Prepare the SQL query
        String query = "DELETE FROM health_data WHERE id = ?";

        // Database logic to insert data using PREPARED Statement
        PreparedStatement statement = con.prepareStatement(query);
        statement.setInt(1, id);

        int updateRow = statement.executeUpdate();
        if (updateRow != 0) {
            return true;
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return false;

}

}
